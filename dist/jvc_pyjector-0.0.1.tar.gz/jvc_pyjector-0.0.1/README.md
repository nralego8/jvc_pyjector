# jvc_pyjector
Basic python library to interface with JVC Projectors
